import HomePage from "./HomePage";

export default function App() {
  return <HomePage />;
}